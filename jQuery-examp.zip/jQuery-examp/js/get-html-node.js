// $(function() {
//   var $listItemHTML = $('li').html();
//   $('li').append('<i>' + $listItemHTML + '</i>');
// });

$(function(){
  var $ListItemHTML = $('li').html();
  $('li').append('<i>' + $ListItemHTML + '</i>');
});